#include "SmoothSort.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

void SmoothSort::buildHeap(std::vector<double>& vec){
    int ln_used[] = {1,0,0,0,0,0,0};
    
    for(int head =0; head<vec.size(); head++){
        
        
            
        
    }
}

//void SmoothSort::mergeHeap(std::vector<double>& vec, int LN_used[], int head){

void SmoothSort::sort(std::vector<double>& vec){
}
