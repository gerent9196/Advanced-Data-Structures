#pragma once
#include "Interfaces03.h"


class LinkedListSort: public ILinkedListSort{
    public:
    LinkedListSort(){
    }
    ~LinkedListSort(){
    }
    LinkedListNode* sort(LinkedListNode * list);
    void MergeSort(LinkedListNode **head);
    LinkedListNode* Merge(LinkedListNode *a, LinkedListNode* b);
    void split(LinkedListNode *start, LinkedListNode** split_a, LinkedListNode** split_b);
    void print(LinkedListNode* head);
};
